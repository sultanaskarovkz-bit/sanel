Положите сюда свои фотографии работ:

elektro-1.jpg ... elektro-6.jpg  - для галереи на странице electrika
santeh-1.jpg  ... santeh-6.jpg   - для галереи на странице santeh
hero-elektro.jpg                 - большое фото в hero для электрики
hero-santeh.jpg                  - большое фото в hero для сантехники

Рекомендуемый размер: 900x680 px, JPEG/WebP, до 200 КБ.

После загрузки фото - в elektro.html и santeh.html найдите блоки
<img src="https://images.unsplash.com/..."> и замените URL на:
<img src="assets/images/elektro-1.jpg">
