/* ===========================================
   MASTER MAN - основной JS
   - Отправка форм в Telegram (или mailto)
   - Reveal анимации при скролле
   - Маска телефона
   =========================================== */

(function(){
  'use strict';

  // ============ Настройки ============
  // ВАЖНО: вставь свои данные. По умолчанию формы отправляются в WhatsApp.
  const CONFIG = {
    whatsapp: '77001234567',       // номер WhatsApp без + и пробелов
    phone:    '+7 700 123 45 67',  // номер для отображения
    // Можно вписать токен бота и chat_id для отправки в Telegram:
    telegramBotToken: '',          // например '1234567890:AAH...'
    telegramChatId:   '',          // например '123456789'
    // Также можно подключить email через formsubmit.co:
    formsubmitEmail:  ''           // например 'master@site.kz'
  };

  // ============ Reveal on scroll ============
  const reveal = () => {
    const els = document.querySelectorAll('.reveal');
    if (!('IntersectionObserver' in window)){
      els.forEach(el => el.classList.add('in'));
      return;
    }
    const io = new IntersectionObserver((entries)=>{
      entries.forEach(e => {
        if (e.isIntersecting){
          e.target.classList.add('in');
          io.unobserve(e.target);
        }
      });
    }, {threshold: .12});
    els.forEach(el => io.observe(el));
  };

  // ============ Маска телефона ============
  const phoneMask = (input) => {
    input.addEventListener('input', function(){
      let v = this.value.replace(/\D/g,'');
      if (v.startsWith('8')) v = '7' + v.slice(1);
      if (!v.startsWith('7')) v = '7' + v;
      v = v.slice(0,11);
      let out = '+7';
      if (v.length > 1) out += ' (' + v.slice(1,4);
      if (v.length >= 5) out += ') ' + v.slice(4,7);
      if (v.length >= 8) out += '-' + v.slice(7,9);
      if (v.length >= 10) out += '-' + v.slice(9,11);
      this.value = out;
    });
    input.addEventListener('focus', function(){
      if (!this.value) this.value = '+7 ';
    });
  };

  // ============ Toast ============
  const showToast = (msg) => {
    let toast = document.querySelector('.toast');
    if (!toast){
      toast = document.createElement('div');
      toast.className = 'toast';
      toast.innerHTML = '<span class="ok">✓</span><span class="msg"></span>';
      document.body.appendChild(toast);
    }
    toast.querySelector('.msg').textContent = msg;
    toast.classList.add('show');
    setTimeout(()=>toast.classList.remove('show'), 4500);
  };

  // ============ Отправка формы ============
  const sendForm = async (form) => {
    const fd = new FormData(form);
    const data = Object.fromEntries(fd.entries());
    const service = form.dataset.service || document.body.dataset.service || 'Заявка';

    // Текст сообщения
    const lines = [
      'Новая заявка с сайта: ' + service,
      '---',
      'Имя: ' + (data.name || '-'),
      'Телефон: ' + (data.phone || '-'),
    ];
    if (data.task) lines.push('Задача: ' + data.task);
    if (data.address) lines.push('Адрес: ' + data.address);
    if (data.time) lines.push('Удобное время: ' + data.time);
    const text = lines.join('\n');

    let sent = false;

    // 1. Telegram (если задан токен)
    if (CONFIG.telegramBotToken && CONFIG.telegramChatId){
      try{
        const r = await fetch(`https://api.telegram.org/bot${CONFIG.telegramBotToken}/sendMessage`,{
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body:JSON.stringify({chat_id: CONFIG.telegramChatId, text})
        });
        sent = r.ok;
      }catch(e){console.warn('TG send failed', e)}
    }

    // 2. formsubmit.co (email)
    if (!sent && CONFIG.formsubmitEmail){
      try{
        const r = await fetch(`https://formsubmit.co/ajax/${CONFIG.formsubmitEmail}`,{
          method:'POST',
          headers:{'Content-Type':'application/json','Accept':'application/json'},
          body:JSON.stringify({...data, _subject:'Заявка с сайта: '+service})
        });
        sent = r.ok;
      }catch(e){console.warn('formsubmit failed', e)}
    }

    // 3. Fallback - WhatsApp
    if (!sent){
      const wa = `https://wa.me/${CONFIG.whatsapp}?text=${encodeURIComponent(text)}`;
      window.open(wa, '_blank');
    }

    showToast('Заявка принята. Мастер свяжется в течение 5 минут.');
    form.reset();
  };

  // ============ Init ============
  document.addEventListener('DOMContentLoaded', () => {
    reveal();

    // Маска телефонов
    document.querySelectorAll('input[type="tel"]').forEach(phoneMask);

    // Обработчик форм
    document.querySelectorAll('form[data-lead]').forEach(form => {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        const btn = form.querySelector('button[type="submit"]');
        if (btn){
          const orig = btn.innerHTML;
          btn.disabled = true;
          btn.innerHTML = 'Отправляем...';
          sendForm(form).finally(() => {
            btn.disabled = false;
            btn.innerHTML = orig;
          });
        } else {
          sendForm(form);
        }
      });
    });

    // Плавный скролл по якорям
    document.querySelectorAll('a[href^="#"]').forEach(a => {
      a.addEventListener('click', (e) => {
        const id = a.getAttribute('href');
        if (id.length > 1){
          const el = document.querySelector(id);
          if (el){
            e.preventDefault();
            const top = el.getBoundingClientRect().top + window.scrollY - 80;
            window.scrollTo({top, behavior:'smooth'});
          }
        }
      });
    });

    // Текущий год в футере
    document.querySelectorAll('[data-year]').forEach(el => {
      el.textContent = new Date().getFullYear();
    });

    // Подставить номер телефона из CONFIG
    document.querySelectorAll('[data-phone]').forEach(el => {
      el.textContent = CONFIG.phone;
    });
    document.querySelectorAll('a[data-phone-link]').forEach(el => {
      el.href = 'tel:' + CONFIG.phone.replace(/\D/g,'');
    });
    document.querySelectorAll('a[data-wa]').forEach(el => {
      el.href = `https://wa.me/${CONFIG.whatsapp}`;
      el.target = '_blank';
    });
  });
})();
